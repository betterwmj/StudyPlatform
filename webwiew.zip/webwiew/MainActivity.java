package com.example.cw5242.cookiedemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText user_name;
    private EditText psw;
    private Button btn;
    private String mUserName;
    private String mPassWord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initData();
        initLister();
    }

    private void initView() {
        user_name = (EditText) findViewById(R.id.user_name);
        psw = (EditText) findViewById(R.id.psw);
        btn = (Button) findViewById(R.id.btn);
    }

    private void initData() {


    }

    private void initLister() {
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mUserName = user_name.getText().toString().trim();
                mPassWord = psw.getText().toString().trim();
                Intent intent = new Intent();
                intent.putExtra("name", mUserName);
                intent.putExtra("psw", mPassWord);
                intent.setClass(getApplication(), WebViewActivity.class);
                startActivity(intent);
            }
        });

    }
}
