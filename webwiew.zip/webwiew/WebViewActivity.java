package com.example.cw5242.cookiedemo;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebViewActivity extends AppCompatActivity {
    private WebView web_view;
    private String mName;
    private String mPsw;
    private String url = "http://192.168.20.62:3006/#!/navigation";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        initView();
        initData();
    }

    private void initView() {
        web_view = (WebView) findViewById(R.id.web_view);
    }


    private void initData() {
        Intent intent = getIntent();
        mName = intent.getStringExtra("name");
        mPsw = intent.getStringExtra("psw");
        Log.d("WebViewActivity", mName + "," + mPsw);
        // 设置可以访问文件
        web_view.getSettings().setAllowFileAccess(true);
        web_view.getSettings().setJavaScriptEnabled(true);
//        web_view.getSettings().setUserAgentString("User-Agent:Android");
//        web_view.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
//        web_view.getSettings().setAppCacheEnabled(true);
//        web_view.getSettings().setDomStorageEnabled(true);
//        web_view.getSettings().setDatabaseEnabled(true);
        synCookies(this, url);
        web_view.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // TODO Auto-generated method stub
                //返回值是true的时候控制去WebView打开，为false调用系统浏览器或第三方浏览器
                view.loadUrl(url);
                return true;
            }
        });

        web_view.loadUrl(url);
    }

    public void synCookies(Context context, String url) {
        try {
            CookieSyncManager.createInstance(context);
            CookieManager cookieManager = CookieManager.getInstance();
            String mCookie = cookieManager.getCookie(url);
            cookieManager.setAcceptCookie(true);
            cookieManager.removeSessionCookie();//移除
            cookieManager.setCookie(url, "username=" + mName);
            cookieManager.setCookie(url, "psw=" + mPsw);
            CookieSyncManager.getInstance().sync();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (web_view.canGoBack()) {
                web_view.goBack();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}
